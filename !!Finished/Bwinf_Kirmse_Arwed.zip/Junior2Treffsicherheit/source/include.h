#include <iostream>
#include <windows.h>
#include <vector>
#include <string.h>
#include <fstream>
#include <sstream>