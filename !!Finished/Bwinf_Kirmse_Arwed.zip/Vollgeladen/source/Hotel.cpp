#include "Hotel.h"

Hotel::Hotel(int EntfernungVonStart, double Bewertung, int Nummer)
{
	this->Entfernung = EntfernungVonStart;
	this->Bewertung = Bewertung;
	this->Nummer = Nummer;
}