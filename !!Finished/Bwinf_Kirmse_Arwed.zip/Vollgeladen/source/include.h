#include <iostream>
#include <windows.h>
#include <vector>
#include <string.h>
#include <fstream>
#include <sstream>
#include <array>
#include <time.h>
#ifndef MY_HEADER_FILE_
#define MY_HEADER_FILE_

struct vec2
{
	int x, y, produkt{};
};

#endif
